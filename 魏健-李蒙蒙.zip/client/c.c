#include "client.h"

//注册
int do_register(int sockfd,staff *sta) {
	
	sta->tip= 'A';
		
	printf("姓名： ");
	scanf("%s",sta->name);
	getchar();
	
	printf("性别： ");
	scanf("%s",sta->sex);
	getchar();

	printf("年龄： ");
	scanf("%s",sta->age);
	getchar();

	printf("密码： ");
	scanf("%s",sta->code);
	getchar();
    
	printf("工号： ");
	scanf("%s",sta->id);
	getchar();

	printf("工资： ");
	scanf("%s",sta->salary);
	getchar();

	send(sockfd, sta, sizeof(staff),0);
    recv(sockfd, sta, sizeof(staff),0);
	return;
}

//登陆
int do_login(int sockfd, staff *sta) {
    
	sta->tip='L';

	printf("类型： ");
	scanf("%s",sta->type);
	getchar();

	printf("姓名： ");
	scanf("%s",sta->name);
	getchar(); //吃掉垃圾字符

	printf("密码： ");
	scanf("%s",sta->code);
	getchar();

	send(sockfd, sta, sizeof(staff),0);
    recv(sockfd, sta, sizeof(staff),0);

	if (sta->type[0] == 1) {
		do_general_user(fd, sta);  //登录为普通用户
	}
	else {
		do_root_user(fd, sta);     //登录root用户
	}
	 return;
  }	

 //管理员添加用户
int do_add(int sockfd,staff *sta) {
    do_register(sockfd,sta);
   
	send(fd, sta, sizeof(staff),0);
    recv(fd, sta, sizeof(staff),0);
	return;
  }	

//管理员用户查询信息：通过工号查看不同的用户用户
int do_search_root_user(int socketfd, staff * sta){
	sta->tip= 'S'; 
	printf("工号： ");
	scanf("%s",sta->id);
	getchar();

	send(fd, sta, sizeof(staff),0);
    recv(fd, sta, sizeof(staff),0);
    if(sta->tip == '\n'){
	printf("系统不能识别 ");
	}	
	//打印查询结果
	else{
	printf("code : %s\n",sta->code);
	printf("name : %s\n", sta->name);
	printf("sex  : %s\n", sta->sex);
	printf("age  : %s\n", sta->age);
	printf("salary : %s\n",sta->salary);
	}
	return;
	
}


//普通 
 int do_find(int sockfd, staff *sta){
	 
	 sta->tip = 'F';

	while(1)
	{
		printf("要查询的信息:");
		scanf("%s", sta->id);
		getchar();

		//客户端，输入#号，返回到上一级菜单
		if(strncmp(sta->id, "#", 1) == 0)
			break;
		//将要查询的信息发送给服务器
		 send(fd, sta, sizeof(staff),0);
		//等待接受服务器，传递回来的信息的注释信息
	     recv(fd, sta, sizeof(staff),0);
		
		 printf("%s\n", sta->id);
	}
	return 0;
}

//普通用户修改信息
int do_update_general_user(int socketfd, staff * sta){
   
	sta->tip= 'U';

	printf("请输入密码: \n");
	scanf("%s",sta->code);
	getchar(); 


	send(fd,sta,sizeof(staff),0);
	recv(fd,sta,sizeof(staff),0);
    return;
}

//管理员修改
int do_update(int sockfd,staff *sta){

	sta->tip= 'U';

	printf("请输入工号：");
	scanf("%s",sta->id);
	getchar();

	printf("密码：");
	scanf("%s",sta->code);
	getchar();

    send(fd,&sta,sizeof(staff),0);
    recv(fd,&sta,sizeof(staff),0);	

// ok !  or  usr alread exist.
	printf("%d\n", sta->tip);

	return 0;

}
//删除用户
int do_delete(int sockfd,staff *sta){
	sta->tip='D';
	printf("请选择要删除的密码：");
	scanf("%hhd",sta->code);
    getchar();
	
	send(fd,&sta,sizeof(staff),0);   
    recv(fd,&sta,sizeof(staff),0);
    return;
}	
//历史
int do_history(int sockfd, staff *sta){

	sta->tip = 'H';

	send(sockfd, &sta, sizeof(staff), 0);

	// 接受服务器，传递回来的历史记录信息
	while(1)
	{
		recv(fd,&sta,sizeof(staff), 0);

		if(sta->id == '\0')
			break;

		//输出历史记录信息
		printf("%s\n", sta->id);
	}

	return 0;
}
