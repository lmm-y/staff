#include <stdio.h>
#include <sys/types.h>    
#include <sys/socket.h>
#include <stdlib.h>
#include <strings.h>
#include <arpa/inet.h>
#include <unistd.h>

#define N 32
#define SERV_PORT     6666
#define SERV_IP_ADDR  "192.168.0.105"
#define QUIT "quit"

#define  R  1   // user - register
#define  L  2   // user - login
#define  F  3   // user - find
#define  H  4   // user - history
#define  U  5   // user - update
#define  Q  6   // user - quit
#define  C  7   // user - change
#define  S  8   // user - search
#define  A  9   // user - add
#define  D  10  // user - del
typedef struct {
	char type[2];   //  类型 0是管理员 1是员工
	char sex[2];    //  性别
	char name[N];   //  名字
	char age[4];    //  年龄
	char code[16];  //  密码
	char id[16];    //  工号
	char salary[8]; //  工资
	int  tip;       //  选项
	char msg[50];   //  数据收发 
 }__attribute__((packed))staff;
//全局变量
staff sta;
int fd;
//自定义的函数
int do_register(int sockfd, staff *sta);
int do_add(int sockfd,staff *sta);
int do_login(int sockfd, staff *sta);
int do_delete(int sockfd,staff *sta);
int do_find(int sockfd, staff *sta);
int do_history(int sockfd, staff *sta);
int do_update(int sockfd,staff *sta);
int do_search_root_user(int socketfd, staff * sta);
int do_update_general_user(int socketfd, staff * sta);
