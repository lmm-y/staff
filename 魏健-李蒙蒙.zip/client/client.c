#include "client.h"

int main(int argc, const char *argv[])
{
	int port = SERV_PORT;
	int choice;
	int status;
	staff sta;
	port = atoi(argv[2]);
	if(port < 1024 || port > 49000) {
		puts("端口号非法");
		exit(1);
	}
	if(argc != 3) {
		printf("usage:%s serverip port .\n",argv[0]);
		return -1;
	}
	//创建套接字
	int fd = -1;
	fd = socket(AF_INET,SOCK_STREAM,0);
	if(fd < 0) {
		perror("socket");
		return -1;
	}
	//填充对方服务器地址
	struct sockaddr_in sin;
	bzero(&sin,sizeof(sin));
	sin.sin_family = AF_INET;
	sin.sin_port = htons(port);
	sin.sin_addr.s_addr = inet_addr(argv[1]);

	//判断是否连接成功
	if(connect(fd,(struct sockaddr *)&sin,sizeof(sin)) < 0) {
		perror("fail to connect");
		return -1;

	}

	//	char buf[100] = {};
	//初始界面
	while(1) {
		printf("             *员工管理系统*             \n");	
		printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		printf("~ 1.注册        2.登陆         3.退出 ~ \n");
		printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		printf("选项 : ");
		scanf("%d",&choice);
	//	while(getchar() != '\n');
		getchar();
		switch(choice) {
		case 1:
			sta.msg[0] = 'R';
			send(fd,&sta,sizeof(staff),0);
			do_register(fd,&sta);
			break;

		case 2:
			sta.msg[0] = 'L';
			send(fd,&sta,sizeof(staff),0);
			do_login(fd,&sta);
			break;

		case 3:
			sta.msg[0] = 'Q';
			send(fd,&sta,sizeof(staff),0);
			close(fd);
			exit(0);

		default:
			puts("输入未知选项，请重新输入: ");
			break;
		}

	}

	return 0;
}

//root用户：在登录时type为0，进入root用户界面
int do_root_user(int fd, staff *sta){
	while(1) {
		int choice;
		printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		printf("1.添加 2.查询 3.修改 4.删除 5.查找 6.退出\n");
		printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		printf("选项： ");
		scanf("%d",&choice);
        getchar();

		switch(choice){
		case 1:
			do_add(fd,sta);
			send(fd,&sta,sizeof(staff),0);
			break;

		case 2:
			do_find(fd,sta);
			send(fd,&sta,sizeof(staff),0);
			break;
		case 3:
			do_update(fd,sta);
			send(fd,&sta,sizeof(staff),0);
			break;		
		case 4:
			do_delete(fd,sta);
			send(fd,&sta,sizeof(staff),0);
			break;
		case 5:
			do_history(fd,sta);
			send(fd,&sta,sizeof(staff),0);
			break;
		case 6:
			sta->tip='Q';
			send(fd,&sta,sizeof(staff),0);
			close(fd);
			return 0;
			break;
		default:
			printf("input error\n");
			break;
			return;
		}
	}

}
//普通用户：在登录时type为1，进入普通用户界面
void do_general_user(int fd, staff *sta){
	int choice;
	while(1){

		printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		printf(" 1.修改           2. 查询          3.退出\n");
		printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		printf("选项 :  ");
		scanf("%d", &choice);
		getchar();

		switch(choice){
        case 1:
			sta->msg[0] = 'C';
			send(fd,sta,sizeof(staff),0);
			do_update_general_user(fd,sta);  //普通用户修改信息
			return;
			break;
		case 2:
			sta->msg[0] = 'S';
			send(fd,sta,sizeof(staff),0);
			do_find(fd,sta); //普通用户查询信息
			break;
		case 3:
			sta->msg[0] = 'Q';
			send(fd,sta,sizeof(staff),0);      //退出
			return;
		default:
			puts("输入未知选项，请重新输入: ");
			break;
		}
	}
}

